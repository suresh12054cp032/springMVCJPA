package com.virtusa.shopping.controllers;

import javax.annotation.PostConstruct;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;

import com.virtusa.shopping.models.Category;
import com.virtusa.shopping.services.CategoryServices;

@Controller
public class CategoryController {

	@Autowired
	private CategoryServices categoryServices;
	
	@GetMapping("/addcategory")
	public String addCategory()
	{
		return "addcategory";
	}
	
	@PostMapping("/savecategory")
	public String saveCategory(@ModelAttribute Category category, Model model)
	{
		
		model.addAttribute("category", categoryServices.saveCategory(category));
		
		return "addcategory";
	}
	
	
}
