package com.virtusa.shopping.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.virtusa.shopping.models.Category;
import com.virtusa.shopping.models.Product;
import com.virtusa.shopping.services.CategoryServices;
import com.virtusa.shopping.services.ProductServices;

@Controller
public class ProductController {

	@Autowired
	private CategoryServices categoryService;
	@Autowired
	private ProductServices productServices;
	
	@ModelAttribute("categories")
	public List<Category> getAllcategories()
	{
		return categoryService.getAllCategories();
	}
	
	@GetMapping("/addproduct")
	public String addProduct()
	{
		return "addproduct";
	}
	
	@PostMapping("/saveproduct")
	public String saveProduct(@ModelAttribute Product product,@RequestParam String categoryInfo,Model model)
	{
		
		String[] data=categoryInfo.split("-");
		
		//System.out.println();
		model.addAttribute("product", productServices.saveProduct(product,Integer.parseInt(data[0])));
		
		
		
		return "addproduct";
	
		
	}
	
}
