package com.virtusa.shopping.services;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.User.UserBuilder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import com.virtusa.shopping.models.User;

@Service("userDetailsService")
public class UserDetailsServiceImpl implements UserDetailsService {

	@Autowired
	private UserServices userServices;
	@Autowired
	private UserRoleService userRoleService;
	
	@Override
	public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
		// TODO Auto-generated method stub
		
		User user=userServices.getUserByName(username);
		UserBuilder userBuilder=null;
		if(user!=null)
		
		{
			userBuilder=org.springframework.security.core.userdetails.User.withUsername(username);
			if(user.getEnabled()!=1)
			userBuilder.disabled(false);
			
			userBuilder.password(user.getPassword());
			String[] authorities= userRoleService.getUserRoleByName(username)
					.stream().map(a -> a.getRoles()).toArray(String[]::new);
			
				userBuilder.authorities(authorities);	
		
	}
		else
		{
			
			throw new UsernameNotFoundException("user not found");
		}
		return userBuilder.build();
	
	}
	
}
