package com.virtusa.shopping.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.virtusa.shopping.models.User;
import com.virtusa.shopping.models.UserRoles;
import com.virtusa.shopping.repositiories.UserRoleRepository;


@Service
public class UserRoleService {

	@Autowired
	private UserRoleRepository userRoleRepo;
	
	public List<UserRoles> getUserRoleByName(String userName)
	{
		return userRoleRepo.getUserRoleByName(userName);
	}

}

