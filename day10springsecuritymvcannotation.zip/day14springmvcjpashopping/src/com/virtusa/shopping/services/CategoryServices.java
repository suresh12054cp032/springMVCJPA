package com.virtusa.shopping.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.virtusa.shopping.models.Category;
import com.virtusa.shopping.repositiories.Categoryrepository;

@Service
public class CategoryServices {

	@Autowired
	private Categoryrepository categoryrepository;
	
	public Category saveCategory(Category category)
	{
		
		return categoryrepository.save(category);
		
	}	
	
	public List<Category> getAllCategories(){
		
		return categoryrepository.findAll();
		
	}
	public Category getCategoryById(int categoryId)
	{
		
		return categoryrepository.findById(categoryId).orElse(null);
	}
	
}
