package com.virtusa.shopping.services;

import javax.management.loading.PrivateClassLoader;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.virtusa.shopping.models.User;
import com.virtusa.shopping.repositiories.UserRepository;

@Service
public class UserServices {

@Autowired
  private UserRepository userrepository;
	
 public User getUserByName(String UserName) {
	 
	 User user=userrepository.findById(UserName).orElse(null);
	 System.out.println("user services="+user.getUserName());
	return user;
	
}


 


}
