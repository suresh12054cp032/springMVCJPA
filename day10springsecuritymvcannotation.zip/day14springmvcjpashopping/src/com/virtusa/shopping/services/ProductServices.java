package com.virtusa.shopping.services;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.virtusa.shopping.models.Category;
import com.virtusa.shopping.models.Product;
import com.virtusa.shopping.repositiories.ProductRepository;

@Service
public class ProductServices {

	@Autowired
	private ProductRepository productrep;
	@Autowired
	private CategoryServices categoryServices;
	
	public Product saveProduct(Product product, int categoryId)
	{
		  Category category=categoryServices.getCategoryById(categoryId);
		  product.setCategory(category);
		return productrep.save(product);
	}
	
}
