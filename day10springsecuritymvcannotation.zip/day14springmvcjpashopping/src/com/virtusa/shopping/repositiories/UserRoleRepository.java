package com.virtusa.shopping.repositiories;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.virtusa.shopping.models.UserRoles;

@Repository
public interface UserRoleRepository extends JpaRepository<UserRoles, String> {
	
	
	//custom jpa method
	
	@Query("SELECT ur FROM UserRoles ur WHERE ur.user.userName=:name")
	List<UserRoles> getUserRoleByName(@Param("name") String name);

}
