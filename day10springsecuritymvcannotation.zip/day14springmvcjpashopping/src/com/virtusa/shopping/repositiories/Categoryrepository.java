package com.virtusa.shopping.repositiories;

import org.springframework.data.jpa.repository.JpaRepository;

import com.virtusa.shopping.models.Category;

public interface Categoryrepository extends JpaRepository<Category, Integer> 
{

	
}
