package com.virtusa.shopping.configurations;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;

import javax.sql.DataSource;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.http.HttpMethod;
import org.springframework.security.authentication.dao.DaoAuthenticationProvider;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.authentication.configurers.provisioning.JdbcUserDetailsManagerConfigurer;
import org.springframework.security.config.annotation.method.configuration.EnableGlobalMethodSecurity;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.builders.WebSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.provisioning.JdbcUserDetailsManager;

import com.virtusa.shopping.services.UserDetailsServiceImpl;


@EnableWebSecurity(debug = true)
@EnableGlobalMethodSecurity(prePostEnabled = true)
@ComponentScan(basePackages={"com.virtusa.shopping.*"})
public class WebSecurityConfig extends WebSecurityConfigurerAdapter {
	private static final Logger logger = Logger.getLogger(WebSecurityConfig.class);
	
	@Autowired
	  private UserDetailsServiceImpl userDetailsService;

	  @Override
	  protected void configure(AuthenticationManagerBuilder auth) throws Exception {

		
		  String log4JPropertyFile = "com/virtusa/shopping/resources/log4j.properties";
		  Properties p = new Properties();

		  try {
		      p.load(new FileInputStream(log4JPropertyFile));
		      PropertyConfigurator.configure(p);
		      logger.info("Wow! I'm configured!");
		  } catch (IOException e) {
		      

		  }
		  
		//logs debug message
			if(logger.isDebugEnabled()){
				logger.debug("configure is executed!");
			}
		
			
	    auth.userDetailsService(userDetailsService).passwordEncoder(new BCryptPasswordEncoder());
	    
		//logs exception
		logger.error("This is Error message", new Exception("Testing"));
	  }

	  @Override
	  protected void configure(HttpSecurity http) throws Exception {

	    http.authorizeRequests().anyRequest().hasAnyRole("ADMIN", "USER")
	    .and()
	    .httpBasic(); // Authenticate users with HTTP basic authentication
	  }
	  
//	  public static void main(String[] args) {
//	     String encoded=new BCryptPasswordEncoder().encode("admin@123");
//	     System.out.println(encoded);
//	  }

  
}
